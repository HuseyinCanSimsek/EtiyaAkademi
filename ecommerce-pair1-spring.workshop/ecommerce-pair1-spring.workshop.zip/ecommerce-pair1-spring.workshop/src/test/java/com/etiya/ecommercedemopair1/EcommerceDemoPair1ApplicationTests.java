package com.etiya.ecommercedemopair1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceDemoPair1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
